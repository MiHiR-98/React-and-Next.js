"use client";

import { useState } from "react";
import { DeleteConfirmationBox } from "./DeleteConfirmationBox";
import { FilterButton } from "./FilterButton";

type TodoItemProps = {
  id: string;
  title: string;
  description: string | null;
  complete: boolean;
  priority: { value: string; label: string; color: string; textColor: string };
  createdAt: string;
  callbackFn: boolean;
  toggleTodo: (id: string, complete: boolean) => void;
  deleteTodo: (id: string) => void;
  updatePriority: (
    id: string,
    priority: { value: string; label: string; color: string; textColor: string }
  ) => void;
  // filterTodo: (priority: {
  //   value: string;
  //   label: string;
  //   color: string;
  //   textColor: string;
  // }) => void;
};

export function TodoItem({
  id,
  title,
  complete,
  description,
  priority,
  createdAt,
  callbackFn,
  toggleTodo,
  deleteTodo,
}: TodoItemProps) {
  const [selectedPriority, setSelectedPriority] = useState(priority);
  const [showDelete, setShowDelete] = useState(false);
  const [items, setItems] = useState(false)

  const currentDate = new Date(createdAt).toLocaleDateString("en-GB");
  const currentTime = new Date(createdAt).toLocaleTimeString("en-GB");

  return (
    <>
      <li
        key={id}
        style={{ borderLeftColor: selectedPriority?.color }}
        className={`relative flex justify-between border-t-0 gap-x-6 px-3 py-5 rounded-md bg-white shadow-lg border-l-8 `}
      >
        <div className="flex min-w-0 gap-x-4">
          <input
            id={id}
            type="checkbox"
            className="cursor-pointer peer"
            defaultChecked={complete}
            onChange={(e) => toggleTodo(id, e.target.checked)}
          />
          <div className="min-w-0 flex-auto">
            <p
              className={`font-semibold leading-6 text-gray-900 ${
                complete ? "line-through text-gray-500" : ""
              }`}
            >
              {title}
            </p>
            <p className="mt-1 truncate text-xs leading-5 text-gray-500">
              {description}
            </p>
          </div>
        </div>

        <button
          type="button"
          className="text-xs bg-black px-1 absolute right-0 top-0 hover:bg-red-600 outline-none"
          onClick={() => setShowDelete(true)}
        >
          X
        </button>
        <div className="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
          <p className="mt-1 text-xs leading-5 text-black">
            Created: <time dateTime={currentDate}>{currentDate}</time>
          </p>
          <p className="mt-1 text-xs leading-5 text-black">
            <time dateTime={currentTime}>{currentTime}</time>
          </p>
        </div>
      </li>
      <DeleteConfirmationBox
        open={showDelete}
        callbackFn={(shouldDelete) => {
          setShowDelete(false);
          shouldDelete && deleteTodo(id);
        }}
      />
    </>
  );
}
