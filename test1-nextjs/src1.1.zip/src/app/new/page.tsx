"use client";

import { PrioritySelector } from "@/components/PrioritySelector";
import { useState } from "react";
import { createTodo } from "../actions/createTodo";

export default function Page() {
  const [selectedPriority, setSelectedPriority] = useState("medium");

  const handlePriorityChange = (newPriority: {
    value: string;
    label: string;
  }) => {
    setSelectedPriority(newPriority.value);
  };

  return (
    <>
      <div className="mx-auto max-w-4xl">
        <form action={createTodo} className="flex gap-2 flex-col">
          <h1 className="text-2xl text-black">Add New Item</h1>
          <label htmlFor="title" className="text-black">
            Title:
          </label>
          <input
            type="text"
            name="title"
            id="title"
            className="border border-black bg-transparent text-black rounded px-2 py-1 outline-none"
          />

          <label htmlFor="description" className="text-black">
            Description:
          </label>
          <textarea
            name="description"
            id="description"
            rows={4}
            className="border border-black bg-transparent text-black rounded-md px-3 py-2 outline-none w-full resize-none"
          />
          {/* <select name="priority" id="priority">
          <option value="a">a</option>
          <option value="b">b</option>
        </select> */}
          <PrioritySelector
            priority={selectedPriority}
            onChange={handlePriorityChange}
          />
          <input type="hidden" name="priority" value={selectedPriority} />

          <div className="flex mt-2">
            <button
              type="submit"
              className="border border-black text-black px-2 py-1 rounded bg-gradient-to-r from-teal-400 to-blue-500 hover:from-pink-500 hover:to-orange-500 outline-none"
            >
              Create
            </button>
          </div>
        </form>
      </div>
    </>
  );
}
