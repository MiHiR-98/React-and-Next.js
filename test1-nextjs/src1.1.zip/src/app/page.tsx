import { TodoItem } from "@/components/TodoItem";
import { prisma } from "@/db";
import { toggleTodo } from "./actions/toggleTodo";
import { deleteTodo } from "./actions/deleteTodo";
import { updatePriority } from "./actions/updatePriority";
import {
  determineColor,
  determineTextColor,
} from "./utilities/determinePriorityColor";
import { FilterButton } from "@/components/FilterButton";
import { filterTodo } from "./actions/filterTodo";
import { useState } from "react";

function getTodos() {
  return prisma.todo.findMany().then((todos) =>
    todos.map((todo) => ({
      ...todo,
      priority: {
        value: todo.priority,
        label: todo.priority,
        color: determineColor(todo.priority),
        textColor: determineTextColor(todo.priority),
      },
    }))
  );
}

export default async function Home() {
  const todos = await getTodos();

  return (
    <>
      <div className="mx-auto max-w-4xl relative">
        <FilterButton />
        <ul className="pl-4 pt-4 flex flex-col gap-2">
          {todos.map((todo) => (
            <TodoItem
              key={todo.id}
              id={todo.id}
              title={todo.title}
              description={todo.description}
              complete={todo.complete}
              priority={todo.priority}
              createdAt={todo.createdAt.toISOString()}
              toggleTodo={toggleTodo}
              deleteTodo={deleteTodo}
              updatePriority={updatePriority}
              callbackFn={false}
            />
          ))}
        </ul>
      </div>
    </>
  );
}
