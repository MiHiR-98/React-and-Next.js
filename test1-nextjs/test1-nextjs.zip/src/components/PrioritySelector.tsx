// PrioritySelector.tsx
import { useState } from 'react';
import { Label, Listbox, ListboxButton, ListboxOption, ListboxOptions } from '@headlessui/react';
import { CheckIcon, ChevronUpDownIcon } from '@heroicons/react/20/solid';

const priorities = [
  {
    value: 'high',
    label: 'High',
    color: 'bg-red-500',
    textColor: 'text-white',
  },
  {
    value: 'medium',
    label: 'Medium',
    color: 'bg-yellow-500',
    textColor: 'text-black',
  },
  {
    value: 'low',
    label: 'Low',
    color: 'bg-green-500',
    textColor: 'text-white',
  },
];
type PrioritySelectorProps = {
  priority: string;
  onChange: (priority: string) => void;
};

export function PrioritySelector({ priority, onChange }: PrioritySelectorProps) {
  const [selected, setSelected] = useState(priorities[0]);

  return (
    <Listbox value={selected} onChange={setSelected}>
      <Label className="block text-sm font-medium leading-6 text-gray-900">Assigned to</Label>
      <div className="relative mt-2">
        <ListboxButton className="relative w-full cursor-default rounded-md bg-white py-1.5 pl-3 pr-10 text-left text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 sm:text-sm sm:leading-6">
          <span className="flex items-center">
            <img alt="" src={selected.avatar} className="h-5 w-5 flex-shrink-0 rounded-full" />
            <span className="block truncate px-2">{selected.label}</span>
          </span>
          <span className="pointer-events-none absolute inset-y-0 right-0 ml-3 flex items-center pr-2">
            <ChevronUpDownIcon aria-hidden="true" className="h-5 w-5 text-gray-400" />
          </span>
        </ListboxButton>

        <ListboxOptions className="absolute z-10 mt-1 max-h-56 w-40 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
        {priorities.map((priority) => (
          <ListboxOption
            key={priority.value}
            value={priority}
            className={`group relative cursor-pointer select-none py-2 pl-3 pr-9 ${priority.color} ${priority.textColor} data-[focus]:bg-indigo-600 data-[focus]:text-white`}
          >
            <span className="ml-3 block truncate font-normal group-data-[selected]:font-semibold">
              {priority.label}
            </span>
          </ListboxOption>
        ))}
      </ListboxOptions>
      </div>
    </Listbox>
  );
}
