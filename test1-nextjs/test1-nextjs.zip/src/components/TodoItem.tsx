"use client";

import { useState } from "react";
// import { PrioritySelector } from "./PrioritySelector";

type TodoItemProps = {
  id: string;
  title: string;
  description: string | null;
  complete: boolean;
  priority: any;
  createdAt: string
  toggleTodo: (id: string, complete: boolean) => void;
  deleteTodo: (id: string) => void;
};

export function TodoItem({
  id,
  title,
  complete,
  description,
  priority,
  createdAt,
  toggleTodo,
  deleteTodo,
}: TodoItemProps) {
  // const [selectedPriority, setSelectedPriority] = useState(priority);

  // const handlePriorityChange = (newPriority: string) => {
  //   setSelectedPriority(newPriority);
  // };

  const formattedDate = new Date(createdAt).toLocaleDateString('en-US');

  return (
    <li className="flex gap-2 items-center">
      <input
        id={id}
        type="checkbox"
        className="cursor-pointer peer"
        defaultChecked={complete}
        onChange={(e) => toggleTodo(id, e.target.checked)}
      />
      <label
        htmlFor={id}
        className="cursor-pointer peer-checked:line-through peer-checked:text-slate-500"
      >
        {title}
      </label>
      <div>
        {description && <p className="text-sm text-gray-500">{description}</p>}
        <p className="text-xs text-gray-400">Created at: {formattedDate}</p>
      </div>
      <p className="text-xs text-gray-400">Priority: {priority}</p>
      <button
        type="button"
        className="border border-slate-300 text-slate-300 px-2 rounded hover:bg-red-600 focus-within:bg-slate-700 outline-none"
        onClick={(e) => deleteTodo(id)}
      >
        Delete
      </button>
      {/* <div className="w-full mt-2">
        <PrioritySelector
          priority={selectedPriority}
          onChange={handlePriorityChange}
        />
      </div> */}
    </li>
  );
}
