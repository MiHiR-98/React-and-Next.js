"use client";

import { PrioritySelector } from "@/components/PrioritySelector";
import { prisma } from "@/db";
import { redirect } from "next/navigation";
import { useState } from "react";

async function createTodo(data: FormData) {
  // "use server";

  const title = data.get("title")?.valueOf();
  const description = data.get("description")?.valueOf();
  // const priority = data.get('priority')?.valueOf();

  // console.log(priority)
  
  if (typeof title !== "string" || title.length === 0) {
    throw new Error("Invalid Title");
  }
  
  if (typeof description !== "string" || description.length === 0) {
    throw new Error("Invalid Description");
  }
  
  console.log(data);
  
  // if (priority.length === 0) {
  //   console.log(priority)
  //   throw new Error("Invalid Priority");
  // }
  await prisma.todo.create({ data: { title, complete: false, description, priority:"dsad"} });
  redirect("/");
}

export default function Page() {
  const [selectedPriority, setSelectedPriority] = useState("medium");

  const handlePriorityChange = (newPriority: any) => {
    setSelectedPriority(newPriority.label);
    console.log(newPriority)
  };
  
  return (
    <>
      <form action={createTodo} className="flex gap-2 flex-col">
        <h1 className="text-2xl">Add New Item</h1>
        <label htmlFor="title">Title:</label>
        <input
          type="text"
          name="title"
          id="title"
          className="border border-slate-300 bg-transparent rounded px-2 py-1 outline-none focus-within: border-slate-100"
        />
        <label htmlFor="description">Description:</label>

        <textarea
          name="description"
          id="description"
          rows={4}
          className="border border-slate-300 bg-transparent rounded-md px-3 py-2 outline-none focus-within: border-slate-100 w-full resize-none"
        />
        {/* <select name="priority" id="priority">
          <option value="a">a</option>
          <option value="b">b</option>
        </select> */}
        <PrioritySelector priority={selectedPriority} onChange={handlePriorityChange} />
        {/* <input type="hidden" name="priority" value={selectedPriority} /> */}

        <div className="flex gap-1">
          <button
            type="submit"
            className="border border-slate-300 text-slate-300 px-2 py-1 rounded hover:bg-slate-700 focus-within:bg-slate-700 outline-none"
          >
            Create
          </button>
        </div>
      </form>
    </>
  );
}
